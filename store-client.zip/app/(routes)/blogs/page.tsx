export const dynamic = "force-static";

function BlogsPage() {
  return <div>BlogsPage</div>;
}

export default BlogsPage;
