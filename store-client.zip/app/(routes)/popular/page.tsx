import React from "react";

const PopularPage = () => {
  return <div>PopularPage</div>;
};

export default PopularPage;
