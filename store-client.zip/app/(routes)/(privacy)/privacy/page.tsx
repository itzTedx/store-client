export const dynamic = "force-static";

function Privacy() {
  return <div>Privacy</div>;
}

export default Privacy;
