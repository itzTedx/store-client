export const dynamic = "force-static";

function TermsCondition() {
  return <div>TermsCondition</div>;
}

export default TermsCondition;
