// import { twConfig } from '@/lib/theme'

// function useBreakpointValue(breakpointValue: string) {
//   const breakpoint = twConfig.theme?.screens[breakpointValue]
//   return Number(breakpoint.slice(0, breakpoint.indexOf('px')))
// }

// export default useBreakpointValue
